﻿namespace Tarefas_App2.View
{
    partial class FormMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblMenu = new Label();
            btnAcessar = new Button();
            button1 = new Button();
            SuspendLayout();
            // 
            // lblMenu
            // 
            lblMenu.AutoSize = true;
            lblMenu.Font = new Font("Segoe UI", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblMenu.Location = new Point(363, 36);
            lblMenu.Name = "lblMenu";
            lblMenu.Size = new Size(170, 70);
            lblMenu.TabIndex = 0;
            lblMenu.Text = "Menu";
            // 
            // btnAcessar
            // 
            btnAcessar.Location = new Point(352, 149);
            btnAcessar.Name = "btnAcessar";
            btnAcessar.Size = new Size(191, 82);
            btnAcessar.TabIndex = 1;
            btnAcessar.Text = "Acessar Tarefas";
            btnAcessar.UseVisualStyleBackColor = true;
            btnAcessar.Click += button1_Click;
            // 
            // button1
            // 
            button1.Location = new Point(352, 268);
            button1.Name = "button1";
            button1.Size = new Size(191, 83);
            button1.TabIndex = 2;
            button1.Text = "Cadastrar Funcionários";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_1;
            // 
            // FormMenu
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Yellow;
            ClientSize = new Size(957, 545);
            Controls.Add(button1);
            Controls.Add(btnAcessar);
            Controls.Add(lblMenu);
            Name = "FormMenu";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblMenu;
        private Button btnAcessar;
        private Button button1;
    }
}