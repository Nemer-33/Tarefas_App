﻿namespace Tarefas_App2.View
{
    partial class FormTarefas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCadTarefas = new Label();
            lblTarefas = new Label();
            textboxTarefa = new TextBox();
            label1 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label2 = new Label();
            selectStatus = new ComboBox();
            tabelaTarefas = new DataGridView();
            Coluna1 = new DataGridViewTextBoxColumn();
            Coluna2 = new DataGridViewTextBoxColumn();
            Coluna3 = new DataGridViewTextBoxColumn();
            btnCadTarefa = new Button();
            CadFunc = new Button();
            ((System.ComponentModel.ISupportInitialize)tabelaTarefas).BeginInit();
            SuspendLayout();
            // 
            // lblCadTarefas
            // 
            lblCadTarefas.AutoSize = true;
            lblCadTarefas.Font = new Font("Segoe UI", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCadTarefas.ForeColor = SystemColors.Control;
            lblCadTarefas.Location = new Point(368, -1);
            lblCadTarefas.Name = "lblCadTarefas";
            lblCadTarefas.Size = new Size(508, 70);
            lblCadTarefas.TabIndex = 0;
            lblCadTarefas.Text = "Cadastro de Tarefas";
            // 
            // lblTarefas
            // 
            lblTarefas.AutoSize = true;
            lblTarefas.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTarefas.ForeColor = SystemColors.Control;
            lblTarefas.Location = new Point(43, 92);
            lblTarefas.Name = "lblTarefas";
            lblTarefas.Size = new Size(70, 25);
            lblTarefas.TabIndex = 1;
            lblTarefas.Text = "Tarefa:";
            // 
            // textboxTarefa
            // 
            textboxTarefa.Location = new Point(119, 86);
            textboxTarefa.Name = "textboxTarefa";
            textboxTarefa.Size = new Size(150, 31);
            textboxTarefa.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.Control;
            label1.Location = new Point(340, 93);
            label1.Name = "label1";
            label1.Size = new Size(57, 25);
            label1.TabIndex = 3;
            label1.Text = "Data:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(412, 87);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(300, 31);
            dateTimePicker1.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.Control;
            label2.Location = new Point(753, 92);
            label2.Name = "label2";
            label2.Size = new Size(70, 25);
            label2.TabIndex = 5;
            label2.Text = "Status:";
            // 
            // selectStatus
            // 
            selectStatus.FormattingEnabled = true;
            selectStatus.Location = new Point(831, 89);
            selectStatus.Name = "selectStatus";
            selectStatus.Size = new Size(182, 33);
            selectStatus.TabIndex = 6;
            // 
            // tabelaTarefas
            // 
            tabelaTarefas.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tabelaTarefas.Columns.AddRange(new DataGridViewColumn[] { Coluna1, Coluna2, Coluna3 });
            tabelaTarefas.Location = new Point(119, 143);
            tabelaTarefas.Name = "tabelaTarefas";
            tabelaTarefas.RowHeadersWidth = 62;
            tabelaTarefas.Size = new Size(994, 415);
            tabelaTarefas.TabIndex = 7;
            // 
            // Coluna1
            // 
            Coluna1.HeaderText = "Tarefa:";
            Coluna1.MinimumWidth = 8;
            Coluna1.Name = "Coluna1";
            Coluna1.Width = 300;
            // 
            // Coluna2
            // 
            Coluna2.HeaderText = "Data:";
            Coluna2.MinimumWidth = 8;
            Coluna2.Name = "Coluna2";
            Coluna2.Width = 300;
            // 
            // Coluna3
            // 
            Coluna3.HeaderText = "Status:";
            Coluna3.MinimumWidth = 8;
            Coluna3.Name = "Coluna3";
            Coluna3.Width = 330;
            // 
            // btnCadTarefa
            // 
            btnCadTarefa.Location = new Point(1142, 59);
            btnCadTarefa.Name = "btnCadTarefa";
            btnCadTarefa.Size = new Size(112, 63);
            btnCadTarefa.TabIndex = 8;
            btnCadTarefa.Text = "Cadastrar Tarefa";
            btnCadTarefa.UseVisualStyleBackColor = true;
            btnCadTarefa.Click += btnCadTarefa_Click;
            // 
            // CadFunc
            // 
            CadFunc.Location = new Point(1142, 143);
            CadFunc.Name = "CadFunc";
            CadFunc.Size = new Size(112, 63);
            CadFunc.TabIndex = 9;
            CadFunc.Text = "Cadastrar Funcionário";
            CadFunc.UseVisualStyleBackColor = true;
            CadFunc.Click += CadFunc_Click;
            // 
            // FormTarefas
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1286, 554);
            Controls.Add(CadFunc);
            Controls.Add(btnCadTarefa);
            Controls.Add(tabelaTarefas);
            Controls.Add(selectStatus);
            Controls.Add(label2);
            Controls.Add(dateTimePicker1);
            Controls.Add(label1);
            Controls.Add(textboxTarefa);
            Controls.Add(lblTarefas);
            Controls.Add(lblCadTarefas);
            Name = "FormTarefas";
            Text = "Form1";
            Load += FormTarefas_Load;
            ((System.ComponentModel.ISupportInitialize)tabelaTarefas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCadTarefas;
        private Label lblTarefas;
        private TextBox textboxTarefa;
        private Label label1;
        private DateTimePicker dateTimePicker1;
        private Label label2;
        private ComboBox selectStatus;
        private DataGridView tabelaTarefas;
        private Button btnCadTarefa;
        private DataGridViewTextBoxColumn Coluna1;
        private DataGridViewTextBoxColumn Coluna2;
        private DataGridViewTextBoxColumn Coluna3;
        private Button CadFunc;
    }
}