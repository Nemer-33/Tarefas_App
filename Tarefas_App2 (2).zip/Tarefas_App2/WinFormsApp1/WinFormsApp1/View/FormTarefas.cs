﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tarefas_App2.Controller;

namespace Tarefas_App2.View
{
    public partial class FormTarefas : Form
    {
        public FormTarefas()
        {
            DataTable tabelaTarefas = new DataTable();


            InitializeComponent();
        }

        private void btnCadTarefa_Click(object sender, EventArgs e)
        {
            TarefaController tarefaController = new TarefaController();
            string status = selectStatus.Text;
            string data = dateTimePicker1.Value.ToShortDateString();
            string nomeTarefa = textboxTarefa.Text;

            if (string.IsNullOrWhiteSpace(nomeTarefa))
            {
                MessageBox.Show("Informe o nome da tarefa.");
                return;
            }
            if (string.IsNullOrWhiteSpace(status))
            {
                MessageBox.Show("Informe o status da tarefa.");
                return;
            }

            try
            {
                tarefaController.cadastrarTarefa(nomeTarefa, data, status);

                MessageBox.Show($"Demanda {nomeTarefa}, com a data {data}. Criada com sucesso.");

            }
            catch (Exception ex)
            {

                MessageBox.Show($"Error ao cadastrar {ex}");
            }


            var listagem = tarefaController.listarTarefa();
            foreach (var item in listagem)
            {
                tabelaTarefas.Rows.Add(item.nomeTarefa, item.data, item.status);
            }


            textboxTarefa.Clear();
            selectStatus.SelectedIndex = -1;
        }

        private void CadFunc_Click(object sender, EventArgs e)
        {
            FormFunc formFunc = new FormFunc();
            formFunc.Show();


        }

        private void FormTarefas_Load(object sender, EventArgs e)
        {

        }
    }
}
