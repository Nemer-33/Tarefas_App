﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Tarefas_App2.Model;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Tarefas_App2.View
{
    public partial class FormFunc : Form
    {
        List<Funcionario> func = new List<Funcionario>();
        public FormFunc()
        {
            InitializeComponent();

        }

        private void button2_Click(object sender, EventArgs e)
        {


            Funcionario f = new Funcionario()
            {
                Nome = txtNome.Text,
                Email = txtEmail.Text,
                Matricula = txtMatricula.Text
                
            };

            string nome = txtNome.Text;
            string email = txtEmail.Text;
            string matricula = txtMatricula.Text;

            if (String.IsNullOrEmpty(nome))
            {
                MessageBox.Show("O nome precisa estar preenchido.");
                return;
            }
            if (String.IsNullOrEmpty(email))
            {
                MessageBox.Show("O email precisa estar preenchido.");
                return;
            }
            if (String.IsNullOrEmpty(matricula))
            {
                MessageBox.Show("A matricula precisa estar preenchida.");
                return;
            }


            tabelaFunc.Rows.Add(nome,email,matricula);

            func.Add(f);
            
            MessageBox.Show("Funcionário cadastrado!");

        }

      
    }
}
