﻿namespace Tarefas_App2.View
{
    partial class FormFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblCadFunc = new Label();
            lblNome = new Label();
            lblEmail = new Label();
            lblMatricula = new Label();
            txtNome = new TextBox();
            txtEmail = new TextBox();
            txtMatricula = new TextBox();
            button1 = new Button();
            button2 = new Button();
            tabelaFunc = new DataGridView();
            Coluna1 = new DataGridViewTextBoxColumn();
            Coluna2 = new DataGridViewTextBoxColumn();
            Coluna3 = new DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)tabelaFunc).BeginInit();
            SuspendLayout();
            // 
            // lblCadFunc
            // 
            lblCadFunc.AutoSize = true;
            lblCadFunc.Font = new Font("Segoe UI", 26F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblCadFunc.ForeColor = SystemColors.Control;
            lblCadFunc.Location = new Point(170, 2);
            lblCadFunc.Name = "lblCadFunc";
            lblCadFunc.Size = new Size(588, 70);
            lblCadFunc.TabIndex = 0;
            lblCadFunc.Text = "Cadastrar Funcionários";
            // 
            // lblNome
            // 
            lblNome.AutoSize = true;
            lblNome.ForeColor = SystemColors.Control;
            lblNome.Location = new Point(36, 81);
            lblNome.Name = "lblNome";
            lblNome.Size = new Size(65, 25);
            lblNome.TabIndex = 1;
            lblNome.Text = "Nome:";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.ForeColor = SystemColors.Control;
            lblEmail.Location = new Point(333, 81);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(58, 25);
            lblEmail.TabIndex = 2;
            lblEmail.Text = "Email:";
            // 
            // lblMatricula
            // 
            lblMatricula.AutoSize = true;
            lblMatricula.ForeColor = SystemColors.Control;
            lblMatricula.Location = new Point(615, 81);
            lblMatricula.Name = "lblMatricula";
            lblMatricula.Size = new Size(88, 25);
            lblMatricula.TabIndex = 3;
            lblMatricula.Text = "Matrícula:";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(120, 75);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(150, 31);
            txtNome.TabIndex = 4;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(397, 78);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(150, 31);
            txtEmail.TabIndex = 5;
            // 
            // txtMatricula
            // 
            txtMatricula.Location = new Point(709, 81);
            txtMatricula.Name = "txtMatricula";
            txtMatricula.Size = new Size(150, 31);
            txtMatricula.TabIndex = 6;
            // 
            // button1
            // 
            button1.Location = new Point(442, 171);
            button1.Name = "button1";
            button1.Size = new Size(8, 8);
            button1.TabIndex = 7;
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(696, 171);
            button2.Name = "button2";
            button2.Size = new Size(112, 73);
            button2.TabIndex = 8;
            button2.Text = "Cadastrar Funcionário";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // tabelaFunc
            // 
            tabelaFunc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            tabelaFunc.Columns.AddRange(new DataGridViewColumn[] { Coluna1, Coluna2, Coluna3 });
            tabelaFunc.Location = new Point(94, 127);
            tabelaFunc.Name = "tabelaFunc";
            tabelaFunc.RowHeadersWidth = 62;
            tabelaFunc.Size = new Size(507, 186);
            tabelaFunc.TabIndex = 9;
            // 
            // Coluna1
            // 
            Coluna1.HeaderText = "Nome:";
            Coluna1.MinimumWidth = 8;
            Coluna1.Name = "Coluna1";
            Coluna1.Width = 150;
            // 
            // Coluna2
            // 
            Coluna2.HeaderText = "Email:";
            Coluna2.MinimumWidth = 8;
            Coluna2.Name = "Coluna2";
            Coluna2.Width = 150;
            // 
            // Coluna3
            // 
            Coluna3.HeaderText = "Matrícula:";
            Coluna3.MinimumWidth = 8;
            Coluna3.Name = "Coluna3";
            Coluna3.Width = 150;
            // 
            // FormFunc
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(128, 64, 64);
            ClientSize = new Size(889, 325);
            Controls.Add(tabelaFunc);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtMatricula);
            Controls.Add(txtEmail);
            Controls.Add(txtNome);
            Controls.Add(lblMatricula);
            Controls.Add(lblEmail);
            Controls.Add(lblNome);
            Controls.Add(lblCadFunc);
            Name = "FormFunc";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)tabelaFunc).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblCadFunc;
        private Label lblNome;
        private Label lblEmail;
        private Label lblMatricula;
        private TextBox txtNome;
        private TextBox txtEmail;
        private TextBox txtMatricula;
        private Button button1;
        private Button button2;
        private DataGridView tabelaFunc;
        private DataGridViewTextBoxColumn Coluna1;
        private DataGridViewTextBoxColumn Coluna2;
        private DataGridViewTextBoxColumn Coluna3;
    }
}